"""API module - FastAPI and gRPC endpoints."""
