"""Models module - ML/Vision/Voice models."""
