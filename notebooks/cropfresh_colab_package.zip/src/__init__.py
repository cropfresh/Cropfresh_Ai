"""
CropFresh AI Service
=====================
AI-powered agricultural marketplace backend.
"""

__version__ = "0.1.0"
